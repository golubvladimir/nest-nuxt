export default {
  'ddd': 111
}

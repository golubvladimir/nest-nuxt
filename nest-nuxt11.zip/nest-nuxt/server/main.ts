import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { Nuxt, Builder } from 'nuxt';
import * as nuxtConfig from './../nuxt.config.js';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  const nuxtServer = await createNuxtServer('0.0.0.0', 3000);

  app.use((request, response, next) => {
    if (/^(?!\/?(api|doc)).+$/.test(request.path)) {
      return nuxtServer.render(request, response);
    } else {
      next();
    }
  })

  app.setGlobalPrefix('api');
  await app.listen(3000);
}

async function createNuxtServer(host, port) {
  const isProd = process.env.NODE_ENV === 'production';

  nuxtConfig['dev'] = !isProd;
  nuxtConfig['server']['host'] = host || '0.0.0.0';
  nuxtConfig['server']['port'] = port || 3000;

  const nuxt = new Nuxt(nuxtConfig);

  if (!isProd) {
    await new Builder(nuxt).build();
  }

  return nuxt;
}

bootstrap();

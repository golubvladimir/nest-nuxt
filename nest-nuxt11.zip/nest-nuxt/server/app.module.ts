import { Module } from '@nestjs/common';
// import { AppController } from './app.controller';
import { EventsGateway } from './app.service';

@Module({
  imports: [],
  // controllers: [AppController],
  providers: [EventsGateway],
})
export class AppModule {}
